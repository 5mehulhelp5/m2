<?php
/**
 *
 */

namespace Dfe\CrPayme\Logger;

class Logger extends \Monolog\Logger
{

}
