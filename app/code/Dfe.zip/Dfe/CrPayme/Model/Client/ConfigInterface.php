<?php
/**
 *
 */

namespace Dfe\CrPayme\Model\Client;

interface ConfigInterface
{
    function setConfig();

    function getConfig($key);
}
